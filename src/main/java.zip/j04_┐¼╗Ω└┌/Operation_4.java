package j04_연산자;

public class Operation_4 {
    public static void main(String[] args) {
        int num = 10;

        num = num + 2;

        num %= 5;

        System.out.println(num);
    }
}
