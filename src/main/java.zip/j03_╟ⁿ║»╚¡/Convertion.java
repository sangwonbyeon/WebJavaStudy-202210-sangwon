package j03_형변화;

public class Convertion {

}
