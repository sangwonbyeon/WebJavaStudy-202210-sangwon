package J01_출력;

/**
 *
 */
public class PrintTest1 {
    public static void main(String[] args) {
        // 한 줄 주석
        /*
        여러줄 주석
         */
        //pvsm, pvsm ctrl+sapcebar
        /**
         *
         * 클래스 또는 메소드의 역활을 명시 설명하기 위한 주석
         */

        //문자열 출력
        System.out.print("이름: ");
        System.out.print("변상원 ");
        System.out.print("주소: ");
        System.out.println("부산 해운대구 우동");

        boolean isUsernameCheckFlag = true;

    }
}
